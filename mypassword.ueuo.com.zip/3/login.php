<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>
<body>
<div id="main">
<div id="login">
<h2>Login</h2>
<form action="authorize.php" method="post">
<label>Username<label>
<input id="name" name="username" placeholder="Username" type="text" autocomplete="off"><br>
<label>Password</label>
<input id="password" name="password" placeholder="Password" type="password" autocomplete="off"><br>
<input name="submit" type="submit" value=" Login ">
<span></span>
</form>
</div>
</div>
</body>
</html>